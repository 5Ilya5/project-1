from django.db import migrations

class Migration(migrations.Migration):

    dependencies = [
        ('recipes', '0003_auto_20230715_1731'),
    ]

    operations = [
        migrations.RenameField(
            model_name='ingredientsamount',
            old_name='ingredients',
            new_name='ingredient',
        ),
    ]